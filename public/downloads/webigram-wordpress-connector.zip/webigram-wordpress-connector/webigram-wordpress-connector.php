<?php
/**
 * Plugin Name: Webigram WordPress Connector
 * Description: Authenticated diagnostics connector for Webigram WordPress Doctor. Exposes health data only when a private connector token is supplied.
 * Version: 1.0.0
 * Author: Webigram
 * Author URI: https://webigram.ir/
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Webigram_WordPress_Connector {
    const VERSION = '1.0.0';
    const OPTION_TOKEN = 'webigram_wordpress_connector_token';

    public static function boot() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_webigram_connector_regenerate', array(__CLASS__, 'regenerate_token'));
    }

    public static function activate() {
        if (!get_option(self::OPTION_TOKEN)) {
            update_option(self::OPTION_TOKEN, wp_generate_password(64, false, false), false);
        }
    }

    private static function token() {
        $token = (string) get_option(self::OPTION_TOKEN, '');
        if ($token === '') {
            $token = wp_generate_password(64, false, false);
            update_option(self::OPTION_TOKEN, $token, false);
        }
        return $token;
    }

    public static function permission(WP_REST_Request $request) {
        $provided = trim((string) $request->get_header('x-webigram-token'));
        if ($provided === '') {
            $auth = trim((string) $request->get_header('authorization'));
            if (stripos($auth, 'bearer ') === 0) {
                $provided = trim(substr($auth, 7));
            }
        }
        $expected = self::token();
        if ($provided === '' || !hash_equals($expected, $provided)) {
            return new WP_Error('webigram_unauthorized', 'Invalid Webigram connector token.', array('status' => 401));
        }
        return true;
    }

    public static function register_routes() {
        register_rest_route('webigram/v1', '/health', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'health'),
            'permission_callback' => array(__CLASS__, 'permission'),
        ));

        register_rest_route('webigram/v1', '/mail-test', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'mail_test'),
            'permission_callback' => array(__CLASS__, 'permission'),
            'args' => array(
                'email' => array(
                    'required' => true,
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function ($value) { return (bool) is_email($value); },
                ),
            ),
        ));
    }

    private static function active_plugins() {
        $active = (array) get_option('active_plugins', array());
        if (is_multisite()) {
            $network = array_keys((array) get_site_option('active_sitewide_plugins', array()));
            $active = array_values(array_unique(array_merge($active, $network)));
        }
        return $active;
    }

    private static function plugin_inventory() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugins = get_plugins();
        $active = self::active_plugins();
        $updates = get_site_transient('update_plugins');
        $out = array();
        foreach ($plugins as $file => $data) {
            $update = isset($updates->response[$file]) ? $updates->response[$file] : null;
            $out[] = array(
                'file' => $file,
                'slug' => dirname($file) === '.' ? basename($file, '.php') : dirname($file),
                'name' => isset($data['Name']) ? wp_strip_all_tags($data['Name']) : $file,
                'version' => isset($data['Version']) ? (string) $data['Version'] : null,
                'active' => in_array($file, $active, true),
                'updateAvailable' => (bool) $update,
                'newVersion' => $update && isset($update->new_version) ? (string) $update->new_version : null,
            );
        }
        return $out;
    }

    private static function theme_inventory() {
        $updates = get_site_transient('update_themes');
        $current = wp_get_theme();
        $out = array();
        foreach (wp_get_themes() as $slug => $theme) {
            $update = isset($updates->response[$slug]) ? $updates->response[$slug] : null;
            $out[] = array(
                'slug' => $slug,
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'active' => $current->get_stylesheet() === $slug,
                'parent' => $theme->parent() ? $theme->parent()->get_stylesheet() : null,
                'updateAvailable' => (bool) $update,
                'newVersion' => $update && isset($update['new_version']) ? (string) $update['new_version'] : null,
            );
        }
        return $out;
    }

    private static function core_update_count() {
        $transient = get_site_transient('update_core');
        if (empty($transient->updates) || !is_array($transient->updates)) {
            return 0;
        }
        foreach ($transient->updates as $update) {
            if (isset($update->response) && $update->response === 'upgrade') {
                return 1;
            }
        }
        return 0;
    }

    private static function cron_info() {
        $cron = function_exists('_get_cron_array') ? _get_cron_array() : array();
        if (!is_array($cron)) {
            $cron = array();
        }
        $now = time();
        $events = 0;
        $overdue = 0;
        $next = array();
        foreach ($cron as $timestamp => $hooks) {
            foreach ((array) $hooks as $hook => $schedules) {
                foreach ((array) $schedules as $instances) {
                    $count = is_array($instances) ? count($instances) : 1;
                    $events += $count;
                    if ((int) $timestamp < ($now - 60)) {
                        $overdue += $count;
                    }
                    if (count($next) < 12) {
                        $next[] = array('hook' => sanitize_text_field($hook), 'timestamp' => (int) $timestamp);
                    }
                }
            }
        }
        $loopback = wp_remote_get(site_url('/wp-cron.php?doing_wp_cron=' . rawurlencode((string) microtime(true))), array(
            'timeout' => 6,
            'redirection' => 2,
            'sslverify' => true,
            'headers' => array('User-Agent' => 'Webigram-WordPress-Connector/' . self::VERSION),
        ));
        $loopback_ok = !is_wp_error($loopback) && wp_remote_retrieve_response_code($loopback) > 0 && wp_remote_retrieve_response_code($loopback) < 500;
        return array(
            'events' => $events,
            'overdue' => $overdue,
            'disableWpCron' => defined('DISABLE_WP_CRON') ? (bool) DISABLE_WP_CRON : false,
            'loopbackOk' => $loopback_ok,
            'loopbackStatus' => is_wp_error($loopback) ? $loopback->get_error_message() : wp_remote_retrieve_response_code($loopback),
            'next' => $next,
        );
    }

    private static function autoload_bytes() {
        global $wpdb;
        $values = array('yes', 'on', 'auto-on', 'auto');
        $placeholders = implode(',', array_fill(0, count($values), '%s'));
        $sql = "SELECT COALESCE(SUM(LENGTH(option_value)),0) FROM {$wpdb->options} WHERE autoload IN ($placeholders)";
        return (int) $wpdb->get_var($wpdb->prepare($sql, ...$values));
    }

    private static function smtp_plugins($plugins) {
        $needles = array('wp-mail-smtp', 'fluent-smtp', 'post-smtp', 'easy-wp-smtp', 'mailgun', 'sendgrid', 'smtp-mailer');
        $out = array();
        foreach ($plugins as $plugin) {
            if (empty($plugin['active'])) continue;
            foreach ($needles as $needle) {
                if (strpos($plugin['slug'], $needle) !== false || stripos($plugin['name'], str_replace('-', ' ', $needle)) !== false) {
                    $out[] = array('slug' => $plugin['slug'], 'name' => $plugin['name'], 'version' => $plugin['version']);
                    break;
                }
            }
        }
        return $out;
    }

    private static function woocommerce_info($plugins) {
        $active = class_exists('WooCommerce');
        if (!$active) {
            foreach ($plugins as $plugin) {
                if ($plugin['active'] && $plugin['slug'] === 'woocommerce') { $active = true; break; }
            }
        }
        if (!$active) return array('active' => false);

        $pending = 0;
        if (function_exists('as_get_scheduled_actions')) {
            $status = class_exists('ActionScheduler_Store') ? ActionScheduler_Store::STATUS_PENDING : 'pending';
            $ids = as_get_scheduled_actions(array('status' => $status, 'per_page' => 101, 'return_format' => 'ids'));
            $pending = is_array($ids) ? count($ids) : 0;
        }
        return array(
            'active' => true,
            'version' => defined('WC_VERSION') ? WC_VERSION : null,
            'cartUrl' => function_exists('wc_get_cart_url') ? wc_get_cart_url() : null,
            'checkoutUrl' => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : null,
            'myAccountUrl' => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : null,
            'actionSchedulerPending' => $pending,
            'actionSchedulerCountCapped' => $pending >= 101,
        );
    }

    public static function health() {
        global $wpdb, $wp_version;
        $plugins = self::plugin_inventory();
        $themes = self::theme_inventory();
        $plugin_updates = array_filter($plugins, function ($p) { return !empty($p['updateAvailable']); });
        $theme_updates = array_filter($themes, function ($t) { return !empty($t['updateAvailable']); });
        $core_updates = self::core_update_count();
        $disk_total = @disk_total_space(ABSPATH);
        $disk_free = @disk_free_space(ABSPATH);

        return rest_ensure_response(array(
            'connector' => array('version' => self::VERSION),
            'wordpress' => array(
                'version' => $wp_version,
                'multisite' => is_multisite(),
                'siteUrl' => site_url('/'),
                'homeUrl' => home_url('/'),
            ),
            'environment' => array(
                'phpVersion' => PHP_VERSION,
                'dbVersion' => $wpdb->db_version(),
                'wpMemoryLimit' => defined('WP_MEMORY_LIMIT') ? WP_MEMORY_LIMIT : null,
                'wpMaxMemoryLimit' => defined('WP_MAX_MEMORY_LIMIT') ? WP_MAX_MEMORY_LIMIT : null,
                'phpMemoryLimit' => ini_get('memory_limit'),
                'uploadMaxFilesize' => ini_get('upload_max_filesize'),
                'postMaxSize' => ini_get('post_max_size'),
                'maxExecutionTime' => (int) ini_get('max_execution_time'),
                'wpDebug' => defined('WP_DEBUG') ? (bool) WP_DEBUG : false,
                'wpDebugDisplay' => defined('WP_DEBUG_DISPLAY') ? (bool) WP_DEBUG_DISPLAY : false,
                'wpDebugLog' => defined('WP_DEBUG_LOG') ? WP_DEBUG_LOG : false,
                'https' => is_ssl(),
                'diskTotalBytes' => is_numeric($disk_total) ? (float) $disk_total : null,
                'diskFreeBytes' => is_numeric($disk_free) ? (float) $disk_free : null,
            ),
            'updates' => array(
                'core' => $core_updates,
                'plugins' => count($plugin_updates),
                'themes' => count($theme_updates),
                'total' => $core_updates + count($plugin_updates) + count($theme_updates),
            ),
            'plugins' => array_values($plugins),
            'themes' => array_values($themes),
            'cron' => self::cron_info(),
            'cache' => array(
                'wpCache' => defined('WP_CACHE') ? (bool) WP_CACHE : false,
                'objectCache' => function_exists('wp_using_ext_object_cache') ? (bool) wp_using_ext_object_cache() : false,
                'advancedCacheFile' => file_exists(WP_CONTENT_DIR . '/advanced-cache.php'),
                'objectCacheFile' => file_exists(WP_CONTENT_DIR . '/object-cache.php'),
            ),
            'database' => array(
                'autoloadBytes' => self::autoload_bytes(),
            ),
            'mail' => array(
                'smtpPlugins' => self::smtp_plugins($plugins),
            ),
            'woocommerce' => self::woocommerce_info($plugins),
            'generatedAt' => gmdate('c'),
        ));
    }

    public static function mail_test(WP_REST_Request $request) {
        $email = sanitize_email((string) $request->get_param('email'));
        if (!is_email($email)) {
            return new WP_Error('webigram_bad_email', 'Invalid email address.', array('status' => 400));
        }
        $subject = sprintf('[Webigram] WordPress mail test from %s', wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES));
        $message = "This is a WordPress wp_mail() test requested from Webigram WordPress Doctor.\n\nSite: " . home_url('/') . "\nTime: " . gmdate('c') . "\n";
        $sent = wp_mail($email, $subject, $message);
        return rest_ensure_response(array(
            'accepted' => (bool) $sent,
            'message' => $sent
                ? 'WordPress accepted the message for sending. Delivery to the inbox is not guaranteed by wp_mail().'
                : 'wp_mail() returned false. Check SMTP/mail configuration and WordPress logs.',
        ));
    }

    public static function admin_menu() {
        add_management_page('Webigram Connector', 'Webigram Connector', 'manage_options', 'webigram-connector', array(__CLASS__, 'admin_page'));
    }

    public static function regenerate_token() {
        if (!current_user_can('manage_options')) wp_die('Forbidden', 403);
        check_admin_referer('webigram_connector_regenerate');
        update_option(self::OPTION_TOKEN, wp_generate_password(64, false, false), false);
        wp_safe_redirect(add_query_arg(array('page' => 'webigram-connector', 'regenerated' => '1'), admin_url('tools.php')));
        exit;
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) return;
        $token = self::token();
        ?>
        <div class="wrap">
            <h1>Webigram WordPress Connector</h1>
            <p>این افزونه فقط برای Deep Scan ابزار WordPress Doctor وبیگرام است. توکن را مثل رمز عبور نگه دارید.</p>
            <table class="widefat striped" style="max-width:900px">
                <tbody>
                    <tr><th style="width:220px">Connector status</th><td><strong style="color:#16803b">Active</strong></td></tr>
                    <tr><th>Health endpoint</th><td><code><?php echo esc_html(rest_url('webigram/v1/health')); ?></code></td></tr>
                    <tr><th>Connector token</th><td><input id="webigram-token" type="text" readonly value="<?php echo esc_attr($token); ?>" style="width:100%;font-family:monospace" /><p><button type="button" class="button" onclick="navigator.clipboard.writeText(document.getElementById('webigram-token').value)">Copy token</button></p></td></tr>
                </tbody>
            </table>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:18px">
                <input type="hidden" name="action" value="webigram_connector_regenerate" />
                <?php wp_nonce_field('webigram_connector_regenerate'); ?>
                <button class="button button-secondary" type="submit" onclick="return confirm('Regenerate token? The old token will stop working immediately.')">Regenerate token</button>
            </form>
            <p style="margin-top:18px;color:#646970">Webigram never needs your WordPress username, password, database password, or hosting credentials.</p>
        </div>
        <?php
    }
}

register_activation_hook(__FILE__, array('Webigram_WordPress_Connector', 'activate'));
Webigram_WordPress_Connector::boot();
